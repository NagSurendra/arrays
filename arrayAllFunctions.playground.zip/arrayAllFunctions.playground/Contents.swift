import UIKit
import Foundation

var arr1 = [1, 2, 3, 4, 5]
var arr2 = [[1, 2, 3], [4, 5, 6]]
print("arr1: \(arr1)")
print("arr2: \(arr2)")

print("Count of arr1: \(arr1.count)")
print("Count of arr2: \(arr2.count)")

print("First element of arr1: \(arr1[0])")
print("Element at index 1 of arr2: \(arr2[0][1])")

arr1.append(6)
arr2[0].append(4)
print("arr1 after appending: \(arr1)")
print("arr2 after appending: \(arr2)")

arr1.insert(0, at: 0)
arr2[1].insert(7, at: 2)
print("arr1 after inserting: \(arr1)")
print("arr2 after inserting: \(arr2)")

arr1.remove(at: 2)
arr2[1].remove(at: 1)
print("arr1 after removing element: \(arr1)")
print("arr2 after removing element: \(arr2)")

arr1.removeLast()
print("arr1 after removing last element: \(arr1)")

var arr3 = [1, 2, 3, 4, 5]
arr3.removeAll()
print("arr3 after removing all elements: \(arr3)")

print("Iterating through arr1:")
for item in arr1 {
    print(item)
}
print("Iterating through arr2:")
for subArray in arr2 {
    for item in subArray {
        print(item)
    }
}
var arr4 = arr1.map { $0 * 2 }
print("arr4 (arr1 elements multiplied by 2): \(arr4)")
//
//var sumArr1 = arr1.reduce(0, +)
//print("Sum of elements in arr1: \(sumArr1)")

var filteredArr1 = arr1.filter { $0 > 2 }
print("Elements in arr1 greater than 2: \(filteredArr1)")

var containsElement = arr1.contains(3)
print("arr1 contains 3: \(containsElement)")

var sortedArr1 = arr1.sorted()
print("arr1 sorted: \(sortedArr1)")

var reversedArr1 = arr1.reversed()
print("arr1 reversed: \(reversedArr1)")

var combinedArray = arr1 + [7, 8, 9]
print("Combined array: \(combinedArray)")

if let index = arr1.firstIndex(of: 4) {
    print("First index of 4 in arr1: \(index)")
}

if let lastIndex = arr1.lastIndex(of: 4) {
    print("Last index of 4 in arr1: \(lastIndex)")
}

arr1.removeSubrange(1...2)
print("arr1 after removing subrange (index 1 to 2): \(arr1)")

let isEmpty = arr1.isEmpty
print("arr1 is empty: \(isEmpty)")

var emptyArray = [Int]()
print("Empty array: \(emptyArray)")

let matrix: [[Int]] = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print("Matrix: \(matrix)")

print("Element at matrix[1][2]: \(matrix[1][2])")
